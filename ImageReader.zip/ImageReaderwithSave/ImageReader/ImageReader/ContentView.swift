import SwiftUI
import UniformTypeIdentifiers
import ImageIO
import UIKit

enum ROIType: String, CaseIterable, Identifiable {
    case freehand = "Freehand"
    case rectangle = "Rectangle"
    case circle = "Circle"
    var id: String { rawValue }
}

struct ContentView: View {
    // Document & share state
    @State private var showingDocumentPicker = false
    @State private var showingShareSheet = false
    @State private var shareItems: [Any] = []

    // Loaded images
    @State private var cgImages: [CGImage] = []
    @State private var currentIndex: Int = 0

    // Zoom & pan
    @State private var scale: CGFloat = 1.0
    @State private var lastScale: CGFloat = 1.0
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    // ROI drawing
    @State private var roiType: ROIType = .freehand
    @State private var isDrawing = false
    @State private var startPoint: CGPoint? = nil
    @State private var currentPoint: CGPoint? = nil
    @State private var currentPath: [CGPoint] = []
    @State private var pathsPerImage: [[[CGPoint]]] = []
    @State private var rectsPerImage: [[CGRect]] = []
    @State private var circlesPerImage: [[CGRect]] = []

    // Preference to capture frame of image stack
    @State private var imageFrame: CGRect = .zero

    var body: some View {
        VStack {
            Picker("ROI Type", selection: $roiType) {
                ForEach(ROIType.allCases) { type in
                    Text(type.rawValue).tag(type)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.horizontal)

            if !cgImages.isEmpty {
                GeometryReader { geo in
                    ZStack {
                        // Base image + annotations
                        contentLayer(size: geo.size)
                    }
                    .background(
                        GeometryReader { proxy in
                            Color.clear
                                .onAppear { imageFrame = proxy.frame(in: .global) }
                        }
                    )
                    .contentShape(Rectangle())
                    .scaleEffect(scale)
                    .offset(offset)
                    .gesture(combinedGesture())
                }
            } else {
                Text("No Images Loaded")
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }

            controlBar()
        }
        .onAppear { resetAll() }
        .sheet(isPresented: $showingDocumentPicker) {
            DocumentPicker(supportedTypes: [UTType.image], allowsMultiple: true) { urls in
                loadImages(from: urls)
            }
        }
        .sheet(isPresented: $showingShareSheet) {
            ActivityView(activityItems: shareItems)
        }
    }

    // MARK: - Content Layer
    @ViewBuilder
    private func contentLayer(size: CGSize) -> some View {
        Image(decorative: cgImages[currentIndex], scale: 1.0)
            .resizable()
            .scaledToFit()
            .frame(width: size.width, height: size.height)
        drawPaths()
        drawRects()
        drawCircles()
        drawCurrent()
    }

    private func drawPaths() -> some View {
        ForEach(pathsPerImage[currentIndex].indices, id: \.self) { idx in
            let pts = pathsPerImage[currentIndex][idx]
            Path { p in
                guard let first = pts.first else { return }
                p.move(to: first)
                for point in pts.dropFirst() { p.addLine(to: point) }
            }
            .stroke(Color.red, lineWidth: 2)
        }
    }

    private func drawRects() -> some View {
        ForEach(rectsPerImage[currentIndex].indices, id: \.self) { idx in
            let rect = rectsPerImage[currentIndex][idx]
            Rectangle()
                .path(in: rect)
                .stroke(Color.blue, lineWidth: 2)
        }
    }

    private func drawCircles() -> some View {
        ForEach(circlesPerImage[currentIndex].indices, id: \.self) { idx in
            let rect = circlesPerImage[currentIndex][idx]
            Ellipse()
                .path(in: rect)
                .stroke(Color.green, lineWidth: 2)
        }
    }

    private func drawCurrent() -> some View {
        Group {
            if isDrawing {
                switch roiType {
                case .freehand:
                    Path { p in
                        guard let first = currentPath.first else { return }
                        p.move(to: first)
                        for point in currentPath.dropFirst() { p.addLine(to: point) }
                    }
                    .stroke(Color.red, lineWidth: 2)

                case .rectangle:
                    if let start = startPoint, let current = currentPoint {
                        let rect = CGRect(
                            x: min(start.x, current.x),
                            y: min(start.y, current.y),
                            width: abs(start.x - current.x),
                            height: abs(start.y - current.y)
                        )
                        Rectangle()
                            .path(in: rect)
                            .stroke(Color.blue, lineWidth: 2)
                    }

                case .circle:
                    if let start = startPoint, let current = currentPoint {
                        let dx = current.x - start.x
                        let dy = current.y - start.y
                        let radius = hypot(dx, dy)
                        let rect = CGRect(
                            x: start.x - radius,
                            y: start.y - radius,
                            width: radius * 2,
                            height: radius * 2
                        )
                        Ellipse()
                            .path(in: rect)
                            .stroke(Color.green, lineWidth: 2)
                    }
                }
            }
        }
    }

    // MARK: - Gestures
    private func combinedGesture() -> some Gesture {
        SimultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged(handleDragChanged)
                .onEnded(handleDragEnded),
            MagnificationGesture()
                .onChanged { val in if !isDrawing { scale = lastScale * val } }
                .onEnded { _ in if !isDrawing { lastScale = scale } }
        )
    }

    private func handleDragChanged(_ value: DragGesture.Value) {
        if isDrawing {
            switch roiType {
            case .freehand:
                currentPath.append(value.location)
            case .rectangle, .circle:
                if startPoint == nil { startPoint = value.location }
                currentPoint = value.location
            }
        } else if scale > 1 {
            offset = CGSize(width: lastOffset.width + value.translation.width,
                            height: lastOffset.height + value.translation.height)
        }
    }

    private func handleDragEnded(_ value: DragGesture.Value) {
        if isDrawing { commitROI() }
        else if scale > 1 { lastOffset = offset }
        else {
            let dx = value.translation.width
            if dx < -50 { goToNext() } else if dx > 50 { goToPrevious() }
        }
    }

    private func commitROI() {
        switch roiType {
        case .freehand:
            pathsPerImage[currentIndex].append(currentPath)
            currentPath.removeAll()

        case .rectangle:
            if let start = startPoint, let end = currentPoint {
                let rect = CGRect(
                    x: min(start.x, end.x),
                    y: min(start.y, end.y),
                    width: abs(start.x - end.x),
                    height: abs(start.y - end.y)
                )
                rectsPerImage[currentIndex].append(rect)
            }

        case .circle:
            if let start = startPoint, let end = currentPoint {
                let dx = end.x - start.x
                let dy = end.y - start.y
                let radius = hypot(dx, dy)
                let rect = CGRect(
                    x: start.x - radius,
                    y: start.y - radius,
                    width: radius * 2,
                    height: radius * 2
                )
                circlesPerImage[currentIndex].append(rect)
            }
        }
        startPoint = nil
        currentPoint = nil
        isDrawing = false
    }

    // MARK: - Controls
    private func controlBar() -> some View {
        HStack(spacing: 16) {
            Button("Open Images") { showingDocumentPicker = true }

            if !cgImages.isEmpty {
                Button("Previous") { goToPrevious() }.disabled(currentIndex == 0)
                Text("\(currentIndex + 1) of \(cgImages.count)")
                Button("Next") { goToNext() }.disabled(currentIndex >= cgImages.count - 1)
                Button(isDrawing ? "Cancel" : "Draw ROI") { toggleDrawing() }
                Button("Undo ROI") { undoLast() }.disabled(!canUndo())
                Button("Reset Zoom") { resetAll() }
                Button("Save") { saveAnnotatedImage() }
            }
        }
        .padding(.horizontal)
    }

    private func toggleDrawing() {
        if isDrawing {
            isDrawing = false
            currentPath.removeAll()
            startPoint = nil
            currentPoint = nil
        } else {
            isDrawing = true
        }
    }

    private func undoLast() {
        switch roiType {
        case .freehand:
            if !pathsPerImage[currentIndex].isEmpty {
                pathsPerImage[currentIndex].removeLast()
            }
        case .rectangle:
            if !rectsPerImage[currentIndex].isEmpty {
                rectsPerImage[currentIndex].removeLast()
            }
        case .circle:
            if !circlesPerImage[currentIndex].isEmpty {
                circlesPerImage[currentIndex].removeLast()
            }
        }
    }

    private func canUndo() -> Bool {
        switch roiType {
        case .freehand: return !pathsPerImage[currentIndex].isEmpty
        case .rectangle: return !rectsPerImage[currentIndex].isEmpty
        case .circle: return !circlesPerImage[currentIndex].isEmpty
        }
    }

    // MARK: - Image Loading & Navigation
    private func loadImages(from urls: [URL]) {
        let images = urls.compactMap { url -> CGImage? in
            let options: [CFString: Any] = [kCGImageSourceShouldCache: true]
            guard let src = CGImageSourceCreateWithURL(url as CFURL, options as CFDictionary),
                  let img = CGImageSourceCreateImageAtIndex(src, 0, options as CFDictionary) else { return nil }
            return img
        }
        cgImages = images
        currentIndex = 0
        pathsPerImage = Array(repeating: [], count: images.count)
        rectsPerImage = Array(repeating: [], count: images.count)
        circlesPerImage = Array(repeating: [], count: images.count)
        resetAll()
    }

    private func goToNext() {
        guard currentIndex < cgImages.count - 1 else { return }
        currentIndex += 1
        resetAll()
    }

    private func goToPrevious() {
        guard currentIndex > 0 else { return }
        currentIndex -= 1
        resetAll()
    }

    private func resetAll() {
        scale = 1.0
        lastScale = 1.0
        offset = .zero
        lastOffset = .zero
        currentPath.removeAll()
        startPoint = nil
        currentPoint = nil
        isDrawing = false
    }

    // MARK: - Save Annotated Image
    private func saveAnnotatedImage() {
        guard let snapshot = windowSnapshot() else { return }
        let scaleFactor = snapshot.scale
        let cropRect = CGRect(
            x: imageFrame.minX * scaleFactor,
            y: imageFrame.minY * scaleFactor,
            width: imageFrame.width * scaleFactor,
            height: imageFrame.height * scaleFactor
        )
        guard let cgCropped = snapshot.cgImage?.cropping(to: cropRect) else { return }
        let finalImage = UIImage(cgImage: cgCropped, scale: scaleFactor, orientation: snapshot.imageOrientation)
        shareItems = [finalImage]
        showingShareSheet = true
    }

    private func windowSnapshot() -> UIImage? {
        guard let window = UIApplication.shared.connectedScenes
                .compactMap({ $0 as? UIWindowScene })
                .first?.windows.first else { return nil }
        let renderer = UIGraphicsImageRenderer(size: window.bounds.size)
        return renderer.image { _ in
            window.drawHierarchy(in: window.bounds, afterScreenUpdates: true)
        }
    }
}

struct ActivityView: UIViewControllerRepresentable {
    let activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
