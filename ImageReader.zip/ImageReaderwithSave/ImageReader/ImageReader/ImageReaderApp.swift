//
//  ImageReaderApp.swift
//  ImageReader
//
//  Created by Talha Iqbal on 17/06/2025.
//

// ImageReaderApp.swift
import SwiftUI

@main
struct ImageReaderApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
